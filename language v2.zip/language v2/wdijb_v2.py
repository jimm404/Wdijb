import sys
import re

class WDIJBInterpreter:
    def __init__(self, width=10, height=10, topology=False):
        self.width = width
        self.height = height
        self.topology = topology
        self.memory = {}  # key = (x,y), value = int
        self.output = ""

    def wrap(self, x, y):
        if self.topology:
            return x % self.width, y % self.height
        return x, y

    def set_cell(self, pos, value):
        x, y = self.wrap(*pos)
        self.memory[(x, y)] = value

    def get_cell(self, pos):
        x, y = self.wrap(*pos)
        return self.memory.get((x, y), 0)

    def run(self, code):
        lines = code.replace("|", "\n").splitlines()

        for line in lines:
            line = line.strip()
            if not line:
                continue

            matches = re.findall(r"#(\d+)\{([^\}]*)\}", line)
            for match in matches:
                pos_index = int(match[0])
                value_str = match[1]

                x, y = divmod(pos_index - 1, self.width)  # convert linear index to (x,y)
                current = self.get_cell((x, y))

                # Calculate value
                if value_str.startswith("+") or value_str.startswith("-"):
                    current += value_str.count("+")
                    current -= value_str.count("-")
                else:
                    try:
                        current = int(value_str)
                    except ValueError:
                        pass

                self.set_cell((x, y), current)

            if "@print" in line:
                self.flush_output()

    def flush_output(self):
        sorted_cells = sorted(self.memory.keys())
        text = "".join(
            chr(self.memory[cell])
            for cell in sorted_cells
            if 0 <= self.memory[cell] <= 255
        )
        print(text)
        self.output += text


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python wdijb.py [--topology] program.wdijb")
        sys.exit(1)

    args = sys.argv[1:]
    topology = False
    if args[0] == "--topology":
        topology = True
        args.pop(0)

    filename = args[0]

    with open(filename, "r") as f:
        code = f.read()

    interpreter = WDIJBInterpreter(topology=topology)
    interpreter.run(code)