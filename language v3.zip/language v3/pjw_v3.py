# pjw_v3.py
import argparse
import os

try:
    import png  # Use pypng for PNG output
except ImportError:
    png = None

# --- Argument parsing ---
parser = argparse.ArgumentParser(description="PJW v4 - Text & RGB mode")
parser.add_argument("--topology", type=str, required=True, help="Input .wdijb file")
parser.add_argument("--mode", type=str, choices=["text", "rgb"], default="text", help="Output mode")
args = parser.parse_args()

# --- Load topology ---
if not os.path.exists(args.topology):
    raise FileNotFoundError(f"Topology file not found: {args.topology}")

with open(args.topology, "r") as f:
    lines = [line.strip() for line in f.readlines() if line.strip()]

# --- Parse cells ---
cells = []
for line in lines:
    if line.startswith("#") and "{" in line and "}" in line:
        val = int(line.split("{")[1].split("}")[0])
        cells.append(val)

# --- Text Mode ---
if args.mode == "text":
    text = "".join(chr(c) for c in cells if 32 <= c <= 126)
    print(text)

# --- RGB Mode ---
elif args.mode == "rgb":
    if png is None:
        raise ImportError("pypng not installed. Install with: pip install pypng")

    # Settings
    width = 8  # you can adjust or calculate dynamically
    height = (len(cells) + width - 1) // width

    # Map cell values to RGB tuples (example mapping)
    rgb_cells = []
    for c in cells:
        rgb = (c % 256, (c * 2) % 256, (c * 3) % 256)  # RGB mapping for variety
        rgb_cells.append(rgb)

    # Fill remaining to complete rectangle
    while len(rgb_cells) < width * height:
        rgb_cells.append((0, 0, 0))

    # Convert to rows for pypng
    rows = []
    for i in range(height):
        row = []
        for j in range(width):
            row.extend(rgb_cells[i*width + j])
        rows.append(row)

    with open("pjw_output.png", "wb") as f:
        w = png.Writer(width, height, greyscale=False)
        w.write(f, rows)

    print("RGB PNG generated: pjw_output.png")