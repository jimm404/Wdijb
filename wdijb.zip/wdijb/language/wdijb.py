import sys
import re

class WDIJBInterpreter:
    def __init__(self):
        self.memory = {}   # chessboard memory
        self.output = ""

    def set_cell(self, pos, value):
        self.memory[pos] = value

    def get_cell(self, pos):
        return self.memory.get(pos, 0)

    def run(self, code):
        # Support both '|' and real newlines as separators
        lines = code.replace("|", "\n").splitlines()

        for line in lines:
            line = line.strip()
            if not line:
                continue

            # Handle assignments: #11{72}, #12{+++}, etc.
            matches = re.findall(r"#(\d+)\{([^\}]*)\}", line)
            for match in matches:
                pos = int(match[0])
                x, y = divmod(pos, 10)
                operations = match[1]

                value = self.get_cell((x, y))

                if operations.startswith("+") or operations.startswith("-"):
                    value += operations.count("+")
                    value -= operations.count("-")
                else:
                    try:
                        value = int(operations)
                    except ValueError:
                        pass

                self.set_cell((x, y), value)

            # Handle commands like @print
            if "@print" in line:
                self.flush_output()

    def flush_output(self):
        sorted_cells = sorted(self.memory.keys())
        text = "".join(
            chr(self.memory[cell])
            for cell in sorted_cells
            if 0 <= self.memory[cell] <= 255
        )
        print(text)
        self.output += text


if __name__ == "__main__":
    if len(sys.argv) < 2:
        print("Usage: python wdijb.py program.wdijb")
        sys.exit(1)

    with open(sys.argv[1], "r") as f:
        code = f.read()

    interpreter = WDIJBInterpreter()
    interpreter.run(code)