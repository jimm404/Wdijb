# 🌀 WDIJB + PJW  
**What Did I Just Build?** + **Please Just Work**  

Welcome to the Dumb & Dumber of esolangs.  

- **WDIJB**: Silent, obedient, confusing.  
- **PJW**: Loud, chaotic, sarcastic debugger.  

---

## ✨ Features
- Write programs in pure gibberish:

#11{72}|#12{101}|#13{108}|#14{108}|#15{111}|@print

- PJW roasts your code randomly while debugging.
- Supports **newlines OR pipes** as separators.
- 40% chance of emotional damage from sarcasm.
- ASCII values, random chaos, occasional “Nice.” on 69.


Run a program in WDIJB:

python wdijb.py examples/hello.wdijb

Run it with PJW (chaos mode):

python pjw.py examples/hello.wdijb

📝 Example programs

hello.wdijb

#11{72}
#12{101}
#13{108}
#14{108}
#15{111}
@print

cursed.wdijb

#1{69}|#2{420}|@print

🤡 Why does this exist?

We don’t know. You don’t know. Nobody knows. But it works (sometimes).

This will be easy
  Bob
  1989–2025

Updates? Just fork it and that's your update.
