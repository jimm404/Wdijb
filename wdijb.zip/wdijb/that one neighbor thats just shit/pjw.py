import sys
import random

def roast_message(cell_value=None, command=None):
    roasts = [
        "Wow... groundbreaking stuff right here.",
        "Sure, let’s pretend that’s intentional.",
        "Against all odds… it didn’t crash.",
        "Bro, did you really mean to do that?",
        "Nice. Totally not cursed.",
        "Wow, such number. Much code.",
        "That’s… one way to use this esolang.",
        "PJW: I have no idea what’s happening, but okay.",
        "You’re really trying your best, huh?",
        "Bold move. Let’s see if it pays off.",
    ]

    if command == "@print":
        return "Against all odds… it actually printed."
    if cell_value == 420:
        return "Bruh. 420? Really?"
    if cell_value == 69:
        return "Nice."
    if cell_value and cell_value > 10000:
        return "That number looks cursed… but okay."

    return random.choice(roasts)

def run_debug(program):
    cells = {}
    # Support both '|' and newlines
    lines = program.replace("|", "\n").splitlines()

    for line in lines:
        line = line.strip()
        if not line:
            continue

        if line.startswith("#"):
            try:
                pos, val = line[1:].split("{")
                pos = pos.strip()
                val = int(val.strip("}"))
                cells[pos] = val
                print(f"[PJW] Line: {line}")
                print(f"[PJW] Cell {pos} = {val}")
                print(f"[PJW] Set cell {pos} = {val}")
                # 40% chance to roast
                if random.random() < 0.4:
                    print(f"[PJW] {roast_message(val)}")
            except Exception as e:
                print(f"[PJW] Error parsing line {line}: {e}")

        elif line.startswith("@print"):
            print(f"[PJW] Line: {line}")
            print(f"[PJW] Command: {line}")
            out = "".join(chr(v) for v in cells.values())
            print(out)
            print(f"[PJW] Printed: '{out}'")
            if random.random() < 0.6:
                print(f"[PJW] {roast_message(command='@print')}")
        else:
            print(f"[PJW] Unknown line: {line}")


if __name__ == "__main__":
    if len(sys.argv) != 2:
        print("Usage: python pjw.py program.wdijb")
        sys.exit(1)

    with open(sys.argv[1]) as f:
        code = f.read()
        run_debug(code)